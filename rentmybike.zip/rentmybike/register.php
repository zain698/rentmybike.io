<?php
// Start the session
session_start();

// Include the header and config files
include('includes/header.php');
include('includes/config.php');

$registration_successful = false;

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the connection is established
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Check if all required fields are set
    $fields = ['username', 'password', 'confirm_password', 'title', 'first_name', 'last_name', 'gender', 'address1', 'address2', 'address3', 'postcode', 'description', 'email', 'telephone'];
    foreach ($fields as $field) {
        if (!isset($_POST[$field])) {
            echo "Field $field is missing.";
            exit();
        }
    }

    // Get form data
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $address1 = mysqli_real_escape_string($conn, $_POST['address1']);
    $address2 = mysqli_real_escape_string($conn, $_POST['address2']);
    $address3 = mysqli_real_escape_string($conn, $_POST['address3']);
    $postcode = mysqli_real_escape_string($conn, $_POST['postcode']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $telephone = mysqli_real_escape_string($conn, $_POST['telephone']);
    
    // Validate password
    if ($password !== $confirm_password) {
        echo "Passwords do not match.";
    } else {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // SQL query to insert data into the 'users' table
        $sql = "INSERT INTO users (username, password, title, first_name, last_name, gender, adress1, adress2, adress3, postcode, description, email, telephone)
                VALUES ('$username', '$hashed_password', '$title', '$first_name', '$last_name', '$gender', '$address1', '$address2', '$address3', '$postcode', '$description', '$email', '$telephone')";

        // Execute the query and check for errors
        if ($conn->query($sql) === TRUE) {
            $registration_successful = true;
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Close the database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h2>Register</h2>
    <form method="POST" action="register.php">
        Username: <input type="text" name="username" required><br>
        Password: <input type="password" name="password" required><br>
        Confirm Password: <input type="password" name="confirm_password" required><br>
        Title: <input type="text" name="title"><br>
        First Name: <input type="text" name="first_name" required><br>
        Last Name: <input type="text" name="last_name" required><br>
        Gender: <input type="text" name="gender"><br>
        Address 1: <input type="text" name="address1" required><br>
        Address 2: <input type="text" name="address2"><br>
        Address 3: <input type="text" name="address3"><br>
        Postcode: <input type="text" name="postcode" required><br>
        Description: <textarea name="description"></textarea><br>
        Email: <input type="email" name="email" required><br>
        Telephone: <input type="text" name="telephone"><br>
        <button type="submit">Register</button>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Check if registration was successful and show alert
            <?php if ($registration_successful) { ?>
                alert('Registration successful! You will be redirected to the login page.');
                window.location.href = 'login.php'; // Redirect after showing the alert
            <?php } ?>
        });
    </script>
</body>
</html>
