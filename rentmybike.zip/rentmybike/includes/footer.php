</div>
    <footer>
        <p>&copy; 2024 RentMyBike.io. All rights reserved.</p>
    </footer>
</body>
</html>
