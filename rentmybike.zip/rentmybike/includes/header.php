<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RentMyBike.io</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/scripts.js" defer></script>
</head>
<body>
    <header>
        <div class="container">
            <h1>RentMyBike.io</h1>
            <nav>
                <a href="index.php">Home</a>
                <?php
                session_start(); // Start the session
                if (isset($_SESSION['username'])) {
                    // If the user is logged in, show the dashboard link
                    echo '<a href="dashboard.php">Dashboard</a>';
                    echo '<a href="logout.php">Logout</a>'; 
                    echo '<a href="about.php">About</a>';
                } else {
                    // If the user is not logged in, show the login and register links
                    echo '<a href="register.php">Register</a>';
                    echo '<a href="login.php">Login</a>';
                    echo '<a href="about.php">About</a>';
                }
                ?>
            </nav>
        </div>
    </header>
    <div class="container">
