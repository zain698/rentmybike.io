<?php include('includes/header.php'); ?>

<h2>Welcome to RentMyBike.io</h2>
<p>We hope you enjoy your experience.</p>

<?php include('includes/footer.php'); ?>