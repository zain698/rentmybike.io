<?php 
include('includes/config.php');
include('includes/header.php'); 
session_start(); 

// Check if the user is logged in
if (!isset($_SESSION['username'])) { 
    header('Location: login.php'); 
    exit(); 
} 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }

        h2, h3 {
            text-align: center;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 3px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #002699;
            color: white;
            font-weight: bold;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        a {
            color: #002699;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .add-bike-btn {
            display: block;
            width: 200px;
            margin: 20px auto;
            padding: 10px;
            background-color: #002699;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
        }

        .add-bike-btn:hover {
            background-color: #45a049;
        }

        .container {
            margin: 0 auto;
            max-width: 80%;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>

        <h3>Your Bikes</h3>
        <table>
            <tr>
                <th>Make</th>
                <th>Model</th>
                <th>Actions</th>
            </tr>
            <?php
            $username = $_SESSION['username'];
            $sql = "SELECT * FROM vehicle_details WHERE user_id=(SELECT user_id FROM users WHERE username=?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row["vehicle_make"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["vehicle_model"]) . "</td>";
                    echo "<td>";
                    echo "<a href='bike_details.php?vehicle_id=" . $row["vehicle_id"] . "'>More Details</a> | ";
                    echo "<a href='javascript:void(0);' onclick='confirmDelete(" . $row["vehicle_id"] . ")'>Delete</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>You have no bikes listed.</td></tr>";
            }

            $stmt->close();
            $conn->close();
            ?>
        </table>

        <a href="add_bike.php" class="add-bike-btn">Add New Bike</a>
    </div>

    <script>
        function confirmDelete(vehicle_id) {
            if (confirm("Are you sure you want to delete this bike?")) {
                window.location.href = "delete_bike.php?vehicle_id=" + vehicle_id;
            }
        }
    </script>
</body>
</html>

<?php include('includes/footer.php'); ?>
