<?php include('includes/header.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - RentMyBike.io</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <h2>About Us</h2>

        <section>
            <h3>Our Mission</h3>
            <p>
                This is a module assignment for SEN4001 called Web Design & Databases.
            </p>
        </section>

        <section>
            <h3>Meet the Team</h3>
            <p>
                Our team is composed of passionate individuals to ensure that RentMyBike.io offers the great user experience and reliable service.
            </p>
            <ul>
                <li><strong>Zain Aminullah - </strong>Student</li>
            </ul>
        </section>

        <section>
            <h3>Contact Us</h3>
            <p>
                If you have any questions, please contact us at:
            </p>
            <ul>
                <li>Email: <a href="mailto:support@rentmybike.io">support@rentmybike.io</a></li>
                <li>Phone: 02920 123 456</li>
                <li>70 Park Place, Cardiff, CF10 3AT</li>
            </ul>
        </section>
    </div>
    
    <?php include('includes/footer.php'); ?>
</body>
</html>
