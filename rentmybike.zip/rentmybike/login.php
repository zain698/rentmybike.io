<?php
include('includes/header.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$login_successful = false; // Flag to indicate successful login

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('includes/config.php');

    // Collect and sanitize form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Retrieve user data from the database
    $stmt = $conn->prepare("SELECT user_id, username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $stored_hashed_password = $row['password'];

        // Verify the password
        if (password_verify($password, $stored_hashed_password)) {
            // Set username to the session to be used across the site
            $_SESSION['username'] = $username;

            
            $login_successful = true;

            // Close the statement and connection
            $stmt->close();
            $conn->close();

            // Output to trigger JavaScript alert and redirect
            echo '<script>
                    window.onload = function() {
                        alert("Login successful! Redirecting to the dashboard.");
                        window.location.href = "dashboard.php";
                    };
                  </script>';
            exit(); // Ensure no further code is executed
        } else {
            echo "Invalid username or password.";
        }
    } else {
        echo "User not found.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h2>Login</h2>
    <form method="POST" action="login.php">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>

    <?php include('includes/footer.php'); ?>
</body>
</html>
