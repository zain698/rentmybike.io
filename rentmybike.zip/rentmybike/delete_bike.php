<?php
include('includes/config.php');
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$vehicle_id = $_GET['id'];
$sql = "DELETE FROM vehicle_details WHERE vehicle_id='$vehicle_id'";

if ($conn->query($sql) === TRUE) {
    echo "Bike deleted successfully!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
header('Location: dashboard.php');
?>
