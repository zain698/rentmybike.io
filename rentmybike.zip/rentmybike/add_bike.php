<?php
// Start the session
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include the header and config files
include('includes/header.php');
include('includes/config.php');

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Ensure the user ID is set in the session
if (!isset($_SESSION['user_id'])) {
    // Fetch the user_id from the database using the username
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $_SESSION['user_id'] = $row['user_id'];
    } else {
        echo "Error: User not found.";
        exit();
    }

    $stmt->close();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize form data
    $user_id = $_SESSION['user_id'];
    $vehicle_make = mysqli_real_escape_string($conn, $_POST['vehicle_make']);
    $vehicle_model = mysqli_real_escape_string($conn, $_POST['vehicle_model']);
    $vehicle_bodytype = mysqli_real_escape_string($conn, $_POST['vehicle_bodytype']);
    $fuel_type = mysqli_real_escape_string($conn, $_POST['fuel_type']);
    $mileage = mysqli_real_escape_string($conn, $_POST['mileage']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $year = mysqli_real_escape_string($conn, $_POST['year']);
    $num_doors = mysqli_real_escape_string($conn, $_POST['num_doors']);
    $video_url = mysqli_real_escape_string($conn, $_POST['video_url']);
    $image_url = mysqli_real_escape_string($conn, $_POST['image_url']);

    // Validate that all required fields are filled
    if (!empty($vehicle_make) && !empty($vehicle_model) && !empty($vehicle_bodytype)) {
        // SQL query to insert data into the 'vehicle_details' table
        $sql = "INSERT INTO vehicle_details (user_id, vehicle_make, vehicle_model, vehicle_bodytype, fuel_type, mileage, location, year, num_doors, video_url, image_url)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issssssisss", $user_id, $vehicle_make, $vehicle_model, $vehicle_bodytype, $fuel_type, $mileage, $location, $year, $num_doors, $video_url, $image_url);

        // Execute the query and check for errors
        if ($stmt->execute()) {
            echo "New bike added successfully";
            header('Location: dashboard.php');
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Please fill in all required fields.";
    }

    // Close the database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Bike</title>
</head>
<body>
    <h2>Add Bike</h2>
    <form method="POST" action="add_bike.php">
        Vehicle Make: <input type="text" name="vehicle_make" required><br>
        Vehicle Model: <input type="text" name="vehicle_model" required><br>
        Vehicle Bodytype: <input type="text" name="vehicle_bodytype" required><br>
        Fuel Type: <input type="text" name="fuel_type" required><br>
        Mileage: <input type="text" name="mileage" required><br>
        Location: <input type="text" name="location" required><br>
        Year: <input type="text" name="year" required><br>
        Number of Doors: <input type="number" name="num_doors" required><br>
        Video URL: <input type="text" name="video_url"><br>
        Image URL: <input type="text" name="image_url"><br>
        <input type="submit" value="Add Bike">
    </form>
</body>
</html>
