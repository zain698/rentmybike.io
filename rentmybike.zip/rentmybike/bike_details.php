<?php
include('includes/config.php');
include('includes/header.php');

// Assuming you're getting the vehicle_id from a GET request
$vehicle_id = isset($_GET['vehicle_id']) ? intval($_GET['vehicle_id']) : 0;

if ($vehicle_id > 0) {
    // Fetch bike details from the database
    $stmt = $conn->prepare("SELECT vehicle_make, vehicle_model, vehicle_bodytype, fuel_type, mileage, location, year, num_doors, video_url, image_url FROM vehicle_details WHERE vehicle_id = ?");
    $stmt->bind_param("i", $vehicle_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $bike = $result->fetch_assoc();
    } else {
        echo "No bike found with this ID.";
        exit();
    }
    $stmt->close();
} else {
    echo "Invalid bike ID.";
    exit();
}

// Handle form submission for updating bike details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect and sanitize form data
    $vehicle_make = mysqli_real_escape_string($conn, $_POST['vehicle_make']);
    $vehicle_model = mysqli_real_escape_string($conn, $_POST['vehicle_model']);
    $vehicle_bodytype = mysqli_real_escape_string($conn, $_POST['vehicle_bodytype']);
    $fuel_type = mysqli_real_escape_string($conn, $_POST['fuel_type']);
    $mileage = mysqli_real_escape_string($conn, $_POST['mileage']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $year = mysqli_real_escape_string($conn, $_POST['year']);
    $num_doors = mysqli_real_escape_string($conn, $_POST['num_doors']);
    $video_url = mysqli_real_escape_string($conn, $_POST['video_url']);
    $image_url = mysqli_real_escape_string($conn, $_POST['image_url']);
    
    // SQL query to update bike details
    $update_sql = "UPDATE vehicle_details 
                   SET vehicle_make=?, vehicle_model=?, vehicle_bodytype=?, fuel_type=?, mileage=?, location=?, year=?, num_doors=?, video_url=?, image_url=?
                   WHERE vehicle_id=?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ssssisssssi", $vehicle_make, $vehicle_model, $vehicle_bodytype, $fuel_type, $mileage, $location, $year, $num_doors, $video_url, $image_url, $vehicle_id);
    
    if ($stmt->execute()) {
        echo "<script>alert('Bike details updated successfully!');</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $stmt->close();
    // Refresh the page to show updated details
    header("Location: bike_details.php?vehicle_id=" . $vehicle_id);
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bike Details</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <h2><?php echo htmlspecialchars($bike['vehicle_make']) . ' ' . htmlspecialchars($bike['vehicle_model']); ?></h2>
        <div class="bike-summary">
            <p><strong>Body Type:</strong> <?php echo htmlspecialchars($bike['vehicle_bodytype']); ?></p>
            <p><strong>Fuel Type:</strong> <?php echo htmlspecialchars($bike['fuel_type']); ?></p>
            <p><strong>Mileage:</strong> <?php echo htmlspecialchars($bike['mileage']); ?> km</p>
            <p><strong>Location:</strong> <?php echo htmlspecialchars($bike['location']); ?></p>
            <p><strong>Year:</strong> <?php echo htmlspecialchars($bike['year']); ?></p>
            <p><strong>Number of Doors:</strong> <?php echo htmlspecialchars($bike['num_doors']); ?></p>

            
            <?php if (!empty($bike['video_url'])): ?>
                <p><strong>Video:</strong> <a href="<?php echo htmlspecialchars($bike['video_url']); ?>" target="_blank">Watch Video</a></p>
            <?php endif; ?>

            <?php if (!empty($bike['image_url'])): ?>
                <p><strong>Image:</strong><br><img src="<?php echo htmlspecialchars($bike['image_url']); ?>" alt="Bike Image" style="max-width:100%;"></p>
            <?php endif; ?>
        </div>
        
        
        <button id="editButton">Edit Bike Details</button>
        
        
        <form id="editForm" method="POST" action="bike_details.php?vehicle_id=<?php echo $vehicle_id; ?>" style="display:none;">
            <h3>Edit Bike Details</h3>
            Vehicle Make: <input type="text" name="vehicle_make" value="<?php echo htmlspecialchars($bike['vehicle_make']); ?>" required><br>
            Vehicle Model: <input type="text" name="vehicle_model" value="<?php echo htmlspecialchars($bike['vehicle_model']); ?>" required><br>
            Vehicle Bodytype: <input type="text" name="vehicle_bodytype" value="<?php echo htmlspecialchars($bike['vehicle_bodytype']); ?>" required><br>
            Fuel Type: <input type="text" name="fuel_type" value="<?php echo htmlspecialchars($bike['fuel_type']); ?>" required><br>
            Mileage: <input type="number" name="mileage" value="<?php echo htmlspecialchars($bike['mileage']); ?>" required><br>
            Location: <input type="text" name="location" value="<?php echo htmlspecialchars($bike['location']); ?>" required><br>
            Year: <input type="number" name="year" value="<?php echo htmlspecialchars($bike['year']); ?>" required><br>
            Number of Doors: <input type="number" name="num_doors" value="<?php echo htmlspecialchars($bike['num_doors']); ?>" required><br>
            Video URL: <input type="text" name="video_url" value="<?php echo htmlspecialchars($bike['video_url']); ?>"><br>
            Image URL: <input type="text" name="image_url" value="<?php echo htmlspecialchars($bike['image_url']); ?>"><br>
            <input type="submit" value="Save Changes">
        </form>
    </div>

    <footer>
        <div class="container">
            <p>&copy; 2024 RentMyBike.io. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Show the form when the "Edit" button is clicked
        document.getElementById('editButton').addEventListener('click', function() {
            document.getElementById('editForm').style.display = 'block';
        });
    </script>
</body>
</html>
